package cipher2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class MisspelledCipher extends Cipher2 {

	private static final long serialVersionUID = 1L;

	public MisspelledCipher() throws FileNotFoundException {
		super();
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("dictionary.txt");
		Scanner scanner = new Scanner(file);
		ArrayList<String> dictionaryList = new ArrayList<String>();
		while (scanner.hasNextLine()) {
			dictionaryList.add(scanner.nextLine());
		}
		words = new String[dictionaryList.size()];
		dictionaryList.toArray(words);
		scanner.close();
		MisspelledCipher cipher2 = new MisspelledCipher();
		cipher2.setVisible(true);
	}

	public void control() throws FileNotFoundException {
		// Updates parameter values
				MisspelledCipher.this.setVisible(false);
				File file = new File(textField_1.getText());
				Scanner scanner = new Scanner(file);
				File outputFile = new File("output.txt");
				PrintStream output = new PrintStream(outputFile);
				int count = 0;
				while (scanner.hasNextLine()) {
					cipher = scanner.nextLine();
					cipher(cipher, output);
					count++;
				}
				output.println();
				output.println(timeTotal);
				scanner.close();
				output.close();
				done.setMessage("Done! Elapsed time per cryptogram: "
						+ (Math.round((double) timeTotal / count))
						+ " milliseconds.");
				done.setVisible(true);
	}
	
	public static void cipher(String cipher, PrintStream output) {
		// Test for time estimate
		long time = System.currentTimeMillis();
		String[] split = cipher.split(" ");
		ArrayList<String> cipherWords = new ArrayList<String>();
		for (int i = 0; i < split.length; i++) {
			if (split[i].charAt(split[i].length() - 1) < (char) 65
					|| split[i].charAt(split[i].length() - 1) > (char) 90) {
				cipherWords.add(split[i].substring(0, split[i].length() - 1));
			} else {
				cipherWords.add(split[i]);
			}
		}
		cipherWords = sort(cipherWords);
		ArrayList<String> cipherWords1 = new ArrayList<String>();
		ArrayList<String> cipherWords2 = new ArrayList<String>();
		ArrayList<String> cipherWords3 = new ArrayList<String>();
		ArrayList<String> cipherWords4 = new ArrayList<String>();
		for (int i = 0; i < cipherWords.size()/4; i++) {
			cipherWords1.add(cipherWords.get(i));
			cipherWords4.add(cipherWords.get(i));
		}
		for (int i = cipherWords.size()/4; i < 2*cipherWords.size()/4; i++) {
			cipherWords1.add(cipherWords.get(i));
			cipherWords2.add(cipherWords.get(i));
		}
		for (int i = 2*cipherWords.size()/4; i < 3*cipherWords.size()/4; i++) {
			cipherWords2.add(cipherWords.get(i));
			cipherWords3.add(cipherWords.get(i));
		}
		for (int i = 3*cipherWords.size()/4; i < cipherWords.size()/4; i++) {
			cipherWords3.add(cipherWords.get(i));
			cipherWords4.add(cipherWords.get(i));
		}
		ArrayList<Key> possibilities1 = solve(cipherWords1);
		ArrayList<Key> possibilities2 = solve(cipherWords2);
		ArrayList<Key> possibilities3 = solve(cipherWords3);
		ArrayList<Key> possibilities4 = solve(cipherWords4);
		ArrayList<Key> possibilities = new ArrayList<Key>();
		for (Key k: possibilities1) {
			possibilities.add(k);
		}
		for (Key k: possibilities2) {
			possibilities.add(k);
		}
		for (Key k: possibilities3) {
			possibilities.add(k);
		}
		for (Key k: possibilities4) {
			possibilities.add(k);
		}
		/*output.println("deciphered possibilities");
		for (int i = 0; i < possibilities.size(); i++) {
			for (int j = 0; j < 26; j++) {
				output.print(possibilities.get(i).toArray()[j] + " ");
			}
			output.println(i);
			output.println(possibilities.get(i).decrypt(cipher));
		}*/
		output.println(System.currentTimeMillis() - time);
		timeTotal += System.currentTimeMillis() - time;
	}
	
	public static ArrayList<Key> solve(ArrayList<String> cipherWords) {
		String first = cipherWords.get(0);
		int wordLength = first.length();
		ArrayList<ArrayList<Integer>> repeats = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < wordLength; i++) {
			for (int j = i + 1; j < wordLength; j++) {
				if (first.charAt(i) == first.charAt(j)) {
					ArrayList<Integer> repeat = new ArrayList<Integer>();
					repeat.add(i);
					repeat.add(j);
					repeats.add(repeat);
				}
			}
		}
		ArrayList<ArrayList<Integer>> differences = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < wordLength; i++) {
			for (int j = i + 1; j < wordLength; j++) {
				if (first.charAt(i) != first.charAt(j)) {
					ArrayList<Integer> difference = new ArrayList<Integer>();
					difference.add(i);
					difference.add(j);
					differences.add(difference);
				}
			}
		}
		ArrayList<Key> possibilities = possibilities(repeats, differences,
				wordLength, first);
		ArrayList<Key> concatenatedPossibilities = new ArrayList<Key>();
		ArrayList<Key> newPossibilities = new ArrayList<Key>();
		String word = new String();
		for (int j = 1; j < cipherWords.size(); j++) {
			word = cipherWords.get(j);
			wordLength = word.length();
			repeats = new ArrayList<ArrayList<Integer>>();
			for (int i = 0; i < wordLength; i++) {
				for (int k = i + 1; k < wordLength; k++) {
					if (word.charAt(i) == word.charAt(k)) {
						ArrayList<Integer> repeat = new ArrayList<Integer>();
						repeat.add(i);
						repeat.add(k);
						repeats.add(repeat);
					}
				}
			}
			differences = new ArrayList<ArrayList<Integer>>();
			for (int i = 0; i < wordLength; i++) {
				for (int k = i + 1; k < wordLength; k++) {
					if (word.charAt(i) != word.charAt(k)) {
						ArrayList<Integer> difference = new ArrayList<Integer>();
						difference.add(i);
						difference.add(k);
						differences.add(difference);
					}
				}
			}
			newPossibilities = possibilities(repeats, differences, wordLength,
					word);
			concatenatedPossibilities = new ArrayList<Key>();
			for (int i = 0; i < possibilities.size(); i++) {
				for (int k = 0; k < newPossibilities.size(); k++) {
					if (possibilities.get(i)
							.compatible(newPossibilities.get(k))) {
						concatenatedPossibilities.add(possibilities.get(i)
								.concatenate(newPossibilities.get(k)));
					}
				}
			}
			possibilities = concatenatedPossibilities;
		}
		return possibilities;
	}
}
