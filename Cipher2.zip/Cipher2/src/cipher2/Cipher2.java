package cipher2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Cipher2 extends JDialog {
	protected static String[] words;

	private static final long serialVersionUID = 1L;
	protected final JPanel contentPanel = new JPanel();

	protected JTextField textField_1 = new JTextField();
	protected JTextField textField_2 = new JTextField();

	protected String cipher;

	protected static long timeTotal = 0;
	

	protected final MessageWindow done = new MessageWindow("Done!",
			"Done! The cryptograms should be solved");
	protected final MessageWindow error = new MessageWindow("Error!",
			"Error! Please make sure to enter valid inputs in all fields!");

	public Cipher2() throws FileNotFoundException {
		// Initialize window
		setTitle("Cryptogram Input");
		setBounds(100, 100, 450, 150);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		// Labels for text fields
		JLabel lblInput1 = new JLabel("Input file:");
		lblInput1.setBounds(21, 11, 100, 25);
		contentPanel.add(lblInput1);

		JLabel lblInput2 = new JLabel("Output file:");
		lblInput2.setBounds(21, 47, 100, 25);
		contentPanel.add(lblInput2);

		// Text fields for data entry
		textField_1.setBounds(114, 11, 298, 25);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setText("input.txt");

		textField_2.setBounds(114, 47, 298, 25);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		textField_2.setText("output.txt");

		getContentPane().add(contentPanel, BorderLayout.CENTER);

		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {
							control();
						} catch (IllegalArgumentException | FileNotFoundException e) {
							// Throws error if the text fields cannot be parsed
							error.setVisible(true);
							Cipher2.this.setVisible(true);
						}
					}
				});
			}
		}
	}

	public void control() throws FileNotFoundException {
		// Updates parameter values
		Cipher2.this.setVisible(false);
		File file = new File(textField_1.getText());
		Scanner scanner = new Scanner(file);
		File outputFile = new File("output.txt");
		PrintStream output = new PrintStream(outputFile);
		int count = 0;
		while (scanner.hasNextLine()) {
			cipher = scanner.nextLine();
			cipher(cipher, output);
			count++;
		}
		output.println();
		output.println(timeTotal);
		scanner.close();
		output.close();
		done.setMessage("Done! Elapsed time per cryptogram: "
				+ (Math.round((double) timeTotal / count))
				+ " milliseconds.");
		done.setVisible(true);
	}
	
	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("dictionary.txt");
		Scanner scanner = new Scanner(file);
		ArrayList<String> dictionaryList = new ArrayList<String>();
		while (scanner.hasNextLine()) {
			dictionaryList.add(scanner.nextLine());
		}
		words = new String[dictionaryList.size()];
		dictionaryList.toArray(words);
		scanner.close();
		Cipher2 cipher2 = new Cipher2();
		cipher2.setVisible(true);
	}

	public static void cipher(String cipher, PrintStream output) {
		// Test for time estimate
		long time = System.currentTimeMillis();
		String[] split = cipher.split(" ");
		ArrayList<String> cipherWords = new ArrayList<String>();
		for (int i = 0; i < split.length; i++) {
			if (split[i].charAt(split[i].length() - 1) < (char) 65
					|| split[i].charAt(split[i].length() - 1) > (char) 90) {
				cipherWords.add(split[i].substring(0, split[i].length() - 1));
			} else {
				cipherWords.add(split[i]);
			}
		}
		cipherWords = sort(cipherWords);
		String first = cipherWords.get(0);
		int wordLength = first.length();
		ArrayList<ArrayList<Integer>> repeats = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < wordLength; i++) {
			for (int j = i + 1; j < wordLength; j++) {
				if (first.charAt(i) == first.charAt(j)) {
					ArrayList<Integer> repeat = new ArrayList<Integer>();
					repeat.add(i);
					repeat.add(j);
					repeats.add(repeat);
				}
			}
		}
		ArrayList<ArrayList<Integer>> differences = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < wordLength; i++) {
			for (int j = i + 1; j < wordLength; j++) {
				if (first.charAt(i) != first.charAt(j)) {
					ArrayList<Integer> difference = new ArrayList<Integer>();
					difference.add(i);
					difference.add(j);
					differences.add(difference);
				}
			}
		}
		ArrayList<Key> possibilities = possibilities(repeats, differences,
				wordLength, first);
		ArrayList<Key> concatenatedPossibilities = new ArrayList<Key>();
		ArrayList<Key> newPossibilities = new ArrayList<Key>();
		String word = new String();
		for (int j = 1; j < cipherWords.size(); j++) {
			word = cipherWords.get(j);
			wordLength = word.length();
			repeats = new ArrayList<ArrayList<Integer>>();
			for (int i = 0; i < wordLength; i++) {
				for (int k = i + 1; k < wordLength; k++) {
					if (word.charAt(i) == word.charAt(k)) {
						ArrayList<Integer> repeat = new ArrayList<Integer>();
						repeat.add(i);
						repeat.add(k);
						repeats.add(repeat);
					}
				}
			}
			differences = new ArrayList<ArrayList<Integer>>();
			for (int i = 0; i < wordLength; i++) {
				for (int k = i + 1; k < wordLength; k++) {
					if (word.charAt(i) != word.charAt(k)) {
						ArrayList<Integer> difference = new ArrayList<Integer>();
						difference.add(i);
						difference.add(k);
						differences.add(difference);
					}
				}
			}
			newPossibilities = possibilities(repeats, differences, wordLength,
					word);
			concatenatedPossibilities = new ArrayList<Key>();
			for (int i = 0; i < possibilities.size(); i++) {
				for (int k = 0; k < newPossibilities.size(); k++) {
					if (possibilities.get(i)
							.compatible(newPossibilities.get(k))) {
						concatenatedPossibilities.add(possibilities.get(i)
								.concatenate(newPossibilities.get(k)));
					}
				}
			}
			possibilities = concatenatedPossibilities;
		}
		output.println("deciphered possibilities");
		for (int i = 0; i < possibilities.size(); i++) {
			for (int j = 0; j < 26; j++) {
				output.print(possibilities.get(i).toArray()[j] + " ");
			}
			output.println(i);
			output.println(possibilities.get(i).decrypt(cipher));
		}
		output.println(System.currentTimeMillis() - time);
		timeTotal += System.currentTimeMillis() - time;
	}

	public static ArrayList<String> sort(ArrayList<String> words) {
		ArrayList<String> returnWords = new ArrayList<String>();
		int iter = words.size();
		for (int i = 0; i < iter; i++) {
			int largest = 0;
			for (int j = 1; j < words.size(); j++) {
				if (words.get(j).length() > words.get(largest).length()) {
					largest = j;
				}
			}
			returnWords.add(words.get(largest));
			words.remove(largest);
		}
		return returnWords;
	}

	public static ArrayList<Key> possibilities(
			ArrayList<ArrayList<Integer>> repeats,
			ArrayList<ArrayList<Integer>> differences, int wordLength,
			String word) {
		ArrayList<Key> possibilities = new ArrayList<Key>();
		String wordPossibility;
		for (int i = 0; i < words.length; i++) {
			boolean valid = true;
			wordPossibility = words[i];
			if (wordPossibility.length() != wordLength) {
				valid = false;
			} else {
				for (int j = 0; j < repeats.size(); j++) {
					if (wordPossibility.charAt(repeats.get(j).get(0)) != wordPossibility
							.charAt(repeats.get(j).get(1))) {
						valid = false;
					}
				}
				for (int j = 0; j < differences.size(); j++) {
					if (wordPossibility.charAt(differences.get(j).get(0)) == wordPossibility
							.charAt(differences.get(j).get(1))) {
						valid = false;
					}
				}
			}
			if (valid) {
				Key key = new Key();
				for (int j = 0; j < word.length(); j++) {
					if (word.charAt(j) == 'a' || word.charAt(j) == 'A') {
						key.setA(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'b' || word.charAt(j) == 'B') {
						key.setB(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'c' || word.charAt(j) == 'C') {
						key.setC(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'd' || word.charAt(j) == 'D') {
						key.setD(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'e' || word.charAt(j) == 'E') {
						key.setE(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'f' || word.charAt(j) == 'F') {
						key.setF(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'g' || word.charAt(j) == 'G') {
						key.setG(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'h' || word.charAt(j) == 'H') {
						key.setH(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'i' || word.charAt(j) == 'I') {
						key.setI(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'j' || word.charAt(j) == 'J') {
						key.setJ(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'k' || word.charAt(j) == 'K') {
						key.setK(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'l' || word.charAt(j) == 'L') {
						key.setL(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'm' || word.charAt(j) == 'M') {
						key.setM(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'n' || word.charAt(j) == 'N') {
						key.setN(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'o' || word.charAt(j) == 'O') {
						key.setO(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'p' || word.charAt(j) == 'P') {
						key.setP(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'q' || word.charAt(j) == 'Q') {
						key.setQ(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'r' || word.charAt(j) == 'R') {
						key.setR(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 's' || word.charAt(j) == 'S') {
						key.setS(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 't' || word.charAt(j) == 'T') {
						key.setT(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'u' || word.charAt(j) == 'U') {
						key.setU(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'v' || word.charAt(j) == 'V') {
						key.setV(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'w' || word.charAt(j) == 'W') {
						key.setW(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'x' || word.charAt(j) == 'X') {
						key.setX(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'y' || word.charAt(j) == 'Y') {
						key.setY(wordPossibility.charAt(j));
					} else {
						key.setZ(wordPossibility.charAt(j));
					}
				}
				possibilities.add(key);
			}
		}
		return possibilities;
	}
}
