package cipher2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;

public class Cipher2 extends JDialog {
	private static String[] words;

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();

	private JTextField textField_1 = new JTextField();
	private JTextField textField_2 = new JTextField();

	private static String cipher;

	private static long timeTotal = 0;
	private static int count = 0;

	private final MessageWindow done = new MessageWindow("Done!", "Done! The cryptograms should be solved");
	private final MessageWindow error = new MessageWindow("Error!",
			"Error! Please make sure to enter valid inputs in all fields!");
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField;

	// Constructor and GUI
	public Cipher2() throws FileNotFoundException {
		// Initialize window
		setTitle("Cryptogram Input");
		setBounds(100, 100, 300, 463);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		// Labels for text fields
		JLabel lblInput1 = new JLabel("Input file:");
		lblInput1.setBounds(10, 41, 100, 25);
		contentPanel.add(lblInput1);

		JLabel lblInput2 = new JLabel("Output file:");
		lblInput2.setBounds(10, 77, 100, 25);
		contentPanel.add(lblInput2);

		// Text fields for data entry
		textField_1.setBounds(103, 41, 171, 25);
		contentPanel.add(textField_1);
		textField_1.setColumns(10);
		textField_1.setText("inputSubstitution.txt");

		textField_2.setBounds(103, 77, 171, 25);
		contentPanel.add(textField_2);
		textField_2.setColumns(10);
		textField_2.setText("outputSubstitution.txt");

		getContentPane().add(contentPanel, BorderLayout.CENTER);

		final JCheckBox chckbxSubstitution = new JCheckBox("Substitution");
		chckbxSubstitution.setBounds(10, 11, 97, 23);
		contentPanel.add(chckbxSubstitution);

		JLabel label = new JLabel("Input file:");
		label.setBounds(10, 143, 100, 25);
		contentPanel.add(label);

		JLabel label_1 = new JLabel("Output file:");
		label_1.setBounds(10, 179, 100, 25);
		contentPanel.add(label_1);

		textField_3 = new JTextField();
		textField_3.setText("inputMisspelled.txt");
		textField_3.setColumns(10);
		textField_3.setBounds(103, 143, 171, 25);
		contentPanel.add(textField_3);

		textField_4 = new JTextField();
		textField_4.setText("outputMisspelled.txt");
		textField_4.setColumns(10);
		textField_4.setBounds(103, 179, 171, 25);
		contentPanel.add(textField_4);

		final JCheckBox chckbxMisspelled = new JCheckBox("Misspelled");
		chckbxMisspelled.setBounds(10, 113, 73, 23);
		contentPanel.add(chckbxMisspelled);

		final JCheckBox chckbxCaesar = new JCheckBox("Caesar");
		chckbxCaesar.setBounds(10, 287, 97, 23);
		contentPanel.add(chckbxCaesar);

		JLabel label_2 = new JLabel("Input file:");
		label_2.setBounds(10, 317, 100, 25);
		contentPanel.add(label_2);

		JLabel label_3 = new JLabel("Output file:");
		label_3.setBounds(10, 353, 100, 25);
		contentPanel.add(label_3);

		textField_5 = new JTextField();
		textField_5.setText("inputCaesar.txt");
		textField_5.setColumns(10);
		textField_5.setBounds(103, 317, 171, 25);
		contentPanel.add(textField_5);

		textField_6 = new JTextField();
		textField_6.setText("outputCaesar.txt");
		textField_6.setColumns(10);
		textField_6.setBounds(103, 353, 171, 25);
		contentPanel.add(textField_6);

		JLabel label_4 = new JLabel("Output file:");
		label_4.setBounds(10, 215, 100, 25);
		contentPanel.add(label_4);

		textField_7 = new JTextField();
		textField_7.setText("outputMisspelled2.txt");
		textField_7.setColumns(10);
		textField_7.setBounds(103, 215, 171, 25);
		contentPanel.add(textField_7);

		JLabel label_5 = new JLabel("Output file:");
		label_5.setBounds(10, 251, 100, 25);
		contentPanel.add(label_5);

		textField_8 = new JTextField();
		textField_8.setText("outputMisspelled3.txt");
		textField_8.setColumns(10);
		textField_8.setBounds(103, 251, 171, 25);
		contentPanel.add(textField_8);

		textField = new JTextField();
		textField.setText("2");
		textField.setColumns(10);
		textField.setBounds(188, 113, 86, 25);
		contentPanel.add(textField);

		JLabel lblNumMisspelled = new JLabel("# of errors:");
		lblNumMisspelled.setHorizontalAlignment(SwingConstants.LEFT);
		lblNumMisspelled.setBounds(103, 113, 107, 25);
		contentPanel.add(lblNumMisspelled);

		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {
							Cipher2.this.setVisible(false);
							if (chckbxMisspelled.isSelected()) {
								// Runs for three different first words in
								// case the first word is misspelled - the
								// algorithm assumes the first word is correct
								// to save time
								control(textField_3, textField_4, Integer.valueOf(textField.getText()), 0);
								control(textField_3, textField_7, Integer.valueOf(textField.getText()), 1);
								control(textField_3, textField_8, Integer.valueOf(textField.getText()), 2);
							}
							if (chckbxSubstitution.isSelected()) {
								control(textField_1, textField_2, 0, 0);
							}
							if (chckbxCaesar.isSelected()) {
								controlCaesar(textField_5, textField_6);
							}
							done.setMessage("Done! Elapsed time per cryptogram: "
									+ (Math.round((double) timeTotal / count)) + " milliseconds.");
							done.setVisible(true);
						} catch (IllegalArgumentException | FileNotFoundException e) {
							// Throws error if the text fields cannot be parsed
							error.setVisible(true);
							Cipher2.this.setVisible(true);
						}
					}
				});
			}
		}
	}

	// Main method
	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("dictionary.txt");
		Scanner scanner = new Scanner(file);
		ArrayList<String> dictionaryList = new ArrayList<String>();
		while (scanner.hasNextLine()) {
			dictionaryList.add(scanner.nextLine());
		}
		words = new String[dictionaryList.size()];
		dictionaryList.toArray(words);
		scanner.close();
		Cipher2 cipher2 = new Cipher2();
		cipher2.setVisible(true);
		// The thread never actually ends for this program. Do either of you
		// know how to kill it? Do I need to use a WindowListener? This isn't a
		// huge deal if we only do one or two runs per session, but could be
		// problematic, especially if we compile it and have to kill each
		// process individually
	}

	// Control method for Caesar ciphers
	public static void controlCaesar(JTextField textField_1, JTextField textField_2) throws FileNotFoundException {
		Scanner into = new Scanner(new File(textField_1.getText()));
		File outputFile = new File(textField_2.getText());
		PrintStream output = new PrintStream(outputFile);
		long time = System.currentTimeMillis();
		long t = time;
		while (into.hasNextLine()) {
			String a = into.nextLine();
			ArrayList<CaesarKey> b = decode(a);
			for (CaesarKey k : b) {
				output.println(k.decrypt(a));
			}
			count++;
			output.println(System.currentTimeMillis()-t);
			t = System.currentTimeMillis();
		}
		into.close();
		timeTotal += System.currentTimeMillis() - time;
		output.println(System.currentTimeMillis() - time);
		output.close();
	}

	public static ArrayList<CaesarKey> decode(String in) {
		String[] split = in.split(" ");
		ArrayList<String> cipherWords = new ArrayList<String>();
		for (int i = 0; i < split.length; i++) {
			if (split[i].charAt(split[i].length() - 1) < (char) 65
					|| split[i].charAt(split[i].length() - 1) > (char) 90) {
				cipherWords.add(split[i].substring(0, split[i].length() - 1));
			} else {
				cipherWords.add(split[i]);
			}
		}
		cipherWords = sort(cipherWords);
		ArrayList<CaesarKey> possibilities = new ArrayList<CaesarKey>();
		for (int shift = 0; shift > -26; shift--) {
			possibilities.add(new CaesarKey(shift));
		}
		ArrayList<CaesarKey> finalPossibilities = new ArrayList<CaesarKey>();
		for (CaesarKey k: possibilities) {
			boolean invalid = false;
			for (String str : cipherWords) {
				int l = str.length();
				boolean valid = false;
				for (String s : words) {
					if (l == s.length()) {
						if (k.decrypt(str).equals(s)) {
							valid = true;
						}
					}
				}
				if (!valid) {
					invalid = true;
				}
			}
			if (!invalid) {
				finalPossibilities.add(k);
			}
		}
		return finalPossibilities;
	}

	// Control method for substitution and misspelled substitution ciphers
	public static void control(JTextField tf1, JTextField tf2, int strikes, int first) throws FileNotFoundException {
		File file = new File(tf1.getText());
		Scanner scanner = new Scanner(file);
		File outputFile = new File(tf2.getText());
		PrintStream output = new PrintStream(outputFile);
		while (scanner.hasNextLine()) {
			cipher = scanner.nextLine();
			String[] split = cipher.split(" ");
			ArrayList<String> cipherWords = new ArrayList<String>();
			for (int i = 0; i < split.length; i++) {
				if (split[i].charAt(split[i].length() - 1) < (char) 65
						|| split[i].charAt(split[i].length() - 1) > (char) 90) {
					cipherWords.add(split[i].substring(0, split[i].length() - 1));
				} else {
					cipherWords.add(split[i]);
				}
			}
			cipher(cipher, cipherWords, output, strikes, first);
			count++;
		}
		output.println();
		scanner.close();
		output.close();
	}

	// Method to find all possible ciphers for a list of words
	public static void cipher(String cipher, ArrayList<String> cipherWords, PrintStream output, int strikes,
			int firstLetter) {
		// Test for time estimate
		long time = System.currentTimeMillis();
		cipherWords = sort(cipherWords);
		String temp = cipherWords.get(0);
		cipherWords.set(0, cipherWords.get(firstLetter));
		cipherWords.set(firstLetter, temp);
		String first = cipherWords.get(0);
		int wordLength = first.length();
		ArrayList<ArrayList<Integer>> repeats = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < wordLength; i++) {
			for (int j = i + 1; j < wordLength; j++) {
				if (first.charAt(i) == first.charAt(j)) {
					ArrayList<Integer> repeat = new ArrayList<Integer>();
					repeat.add(i);
					repeat.add(j);
					repeats.add(repeat);
				}
			}
		}
		ArrayList<ArrayList<Integer>> differences = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < wordLength; i++) {
			for (int j = i + 1; j < wordLength; j++) {
				if (first.charAt(i) != first.charAt(j)) {
					ArrayList<Integer> difference = new ArrayList<Integer>();
					difference.add(i);
					difference.add(j);
					differences.add(difference);
				}
			}
		}
		ArrayList<Key> possibilities = possibilities(repeats, differences, wordLength, first);
		ArrayList<Key> concatenatedPossibilities = new ArrayList<Key>();
		ArrayList<Key> newPossibilities = new ArrayList<Key>();
		String word = new String();
		for (int j = 1; j < cipherWords.size(); j++) {
			word = cipherWords.get(j);
			wordLength = word.length();
			repeats = new ArrayList<ArrayList<Integer>>();
			for (int i = 0; i < wordLength; i++) {
				for (int k = i + 1; k < wordLength; k++) {
					if (word.charAt(i) == word.charAt(k)) {
						ArrayList<Integer> repeat = new ArrayList<Integer>();
						repeat.add(i);
						repeat.add(k);
						repeats.add(repeat);
					}
				}
			}
			differences = new ArrayList<ArrayList<Integer>>();
			for (int i = 0; i < wordLength; i++) {
				for (int k = i + 1; k < wordLength; k++) {
					if (word.charAt(i) != word.charAt(k)) {
						ArrayList<Integer> difference = new ArrayList<Integer>();
						difference.add(i);
						difference.add(k);
						differences.add(difference);
					}
				}
			}
			newPossibilities = possibilities(repeats, differences, wordLength, word);
			concatenatedPossibilities = new ArrayList<Key>();
			for (int i = 0; i < possibilities.size(); i++) {
				boolean done = false;
				for (int k = 0; k < newPossibilities.size(); k++) {
					if (possibilities.get(i).compatible(newPossibilities.get(k))) {
						concatenatedPossibilities.add(possibilities.get(i).concatenate(newPossibilities.get(k)));
						done = true;
					}
				}
				if (possibilities.get(i).getStrikes() < strikes && !done) {
					concatenatedPossibilities.add(possibilities.get(i));
					possibilities.get(i).iterStrikes();
				}
			}
			possibilities = concatenatedPossibilities;
		}
		// Writes possibilities to file
		output.println("deciphered possibilities");
		for (int i = 0; i < possibilities.size(); i++) {
			output.println(i);
			output.println(possibilities.get(i).decrypt(cipher));
		}
		output.println(System.currentTimeMillis() - time);
		timeTotal += System.currentTimeMillis() - time;
	}

	// Method to sort a list by length of string - this prioritizes long words
	// which are more likely to be unique, eliminating possibilities as early as
	// possible (saves time)
	public static ArrayList<String> sort(ArrayList<String> words) {
		ArrayList<String> returnWords = new ArrayList<String>();
		int iter = words.size();
		for (int i = 0; i < iter; i++) {
			int largest = 0;
			for (int j = 1; j < words.size(); j++) {
				if (words.get(j).length() > words.get(largest).length()) {
					largest = j;
				}
			}
			returnWords.add(words.get(largest));
			words.remove(largest);
		}
		return returnWords;
	}

	// Method to find the possible ciphers for one word
	public static ArrayList<Key> possibilities(ArrayList<ArrayList<Integer>> repeats,
			ArrayList<ArrayList<Integer>> differences, int wordLength, String word) {
		ArrayList<Key> possibilities = new ArrayList<Key>();
		String wordPossibility;
		for (int i = 0; i < words.length; i++) {
			boolean valid = true;
			wordPossibility = words[i];
			if (wordPossibility.length() != wordLength) {
				valid = false;
			} else {
				for (int j = 0; j < repeats.size(); j++) {
					if (wordPossibility.charAt(repeats.get(j).get(0)) != wordPossibility
							.charAt(repeats.get(j).get(1))) {
						valid = false;
					}
				}
				for (int j = 0; j < differences.size(); j++) {
					if (wordPossibility.charAt(differences.get(j).get(0)) == wordPossibility
							.charAt(differences.get(j).get(1))) {
						valid = false;
					}
				}
			}
			if (valid) {
				Key key = new Key();
				for (int j = 0; j < word.length(); j++) {
					if (word.charAt(j) == 'a' || word.charAt(j) == 'A') {
						key.setA(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'b' || word.charAt(j) == 'B') {
						key.setB(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'c' || word.charAt(j) == 'C') {
						key.setC(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'd' || word.charAt(j) == 'D') {
						key.setD(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'e' || word.charAt(j) == 'E') {
						key.setE(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'f' || word.charAt(j) == 'F') {
						key.setF(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'g' || word.charAt(j) == 'G') {
						key.setG(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'h' || word.charAt(j) == 'H') {
						key.setH(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'i' || word.charAt(j) == 'I') {
						key.setI(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'j' || word.charAt(j) == 'J') {
						key.setJ(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'k' || word.charAt(j) == 'K') {
						key.setK(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'l' || word.charAt(j) == 'L') {
						key.setL(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'm' || word.charAt(j) == 'M') {
						key.setM(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'n' || word.charAt(j) == 'N') {
						key.setN(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'o' || word.charAt(j) == 'O') {
						key.setO(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'p' || word.charAt(j) == 'P') {
						key.setP(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'q' || word.charAt(j) == 'Q') {
						key.setQ(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'r' || word.charAt(j) == 'R') {
						key.setR(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 's' || word.charAt(j) == 'S') {
						key.setS(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 't' || word.charAt(j) == 'T') {
						key.setT(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'u' || word.charAt(j) == 'U') {
						key.setU(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'v' || word.charAt(j) == 'V') {
						key.setV(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'w' || word.charAt(j) == 'W') {
						key.setW(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'x' || word.charAt(j) == 'X') {
						key.setX(wordPossibility.charAt(j));
					} else if (word.charAt(j) == 'y' || word.charAt(j) == 'Y') {
						key.setY(wordPossibility.charAt(j));
					} else {
						key.setZ(wordPossibility.charAt(j));
					}
				}
				possibilities.add(key);
			}
		}
		return possibilities;
	}
}
