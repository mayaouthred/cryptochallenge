package cipher2;

public class CaesarKey {
	private int shift;

	public CaesarKey(int shiftSpaces) {
		shift = shiftSpaces;
	}

	public CaesarKey() {
	}
	
	public String decrypt(String original) {
		StringBuilder sb = new StringBuilder();
		for (int iter = 0; iter < original.length(); iter++) {
			if (original.charAt(iter)+shift > 64 && original.charAt(iter) < 91) {
				sb.append((char) (original.charAt(iter)+shift));
			} else if (original.charAt(iter) > 64 && original.charAt(iter) < 91) {
				sb.append((char) (original.charAt(iter)+26+shift));
			} else {
				sb.append(original.charAt(iter));
			}
		}
		return sb.toString();
	}
	
	public void setShift(int spaces) {
		shift = spaces;
	}
	
	public int getShift() {
		return shift;
	}
}
