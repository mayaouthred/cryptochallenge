package cipher2;

public class Key {
	private char a;
	private char b;
	private char c;
	private char d;
	private char e;
	private char f;
	private char g;
	private char h;
	private char i;
	private char j;
	private char k;
	private char l;
	private char m;
	private char n;
	private char o;
	private char p;
	private char q;
	private char r;
	private char s;
	private char t;
	private char u;
	private char v;
	private char w;
	private char x;
	private char y;
	private char z;
	private char nullChar;

	public Key() {
	}

	public String decrypt(String original) {
		StringBuilder sb = new StringBuilder();
		for (int iter = 0; iter < original.length(); iter++) {
			if (original.charAt(iter) == 'A') {
				sb.append(a);
			} else if (original.charAt(iter) == 'B') {
				sb.append(b);
			} else if (original.charAt(iter) == 'C') {
				sb.append(c);
			} else if (original.charAt(iter) == 'D') {
				sb.append(d);
			} else if (original.charAt(iter) == 'E') {
				sb.append(e);
			} else if (original.charAt(iter) == 'F') {
				sb.append(f);
			} else if (original.charAt(iter) == 'G') {
				sb.append(g);
			} else if (original.charAt(iter) == 'H') {
				sb.append(h);
			} else if (original.charAt(iter) == 'I') {
				sb.append(i);
			} else if (original.charAt(iter) == 'J') {
				sb.append(j);
			} else if (original.charAt(iter) == 'K') {
				sb.append(k);
			} else if (original.charAt(iter) == 'L') {
				sb.append(l);
			} else if (original.charAt(iter) == 'M') {
				sb.append(m);
			} else if (original.charAt(iter) == 'N') {
				sb.append(n);
			} else if (original.charAt(iter) == 'O') {
				sb.append(o);
			} else if (original.charAt(iter) == 'P') {
				sb.append(p);
			} else if (original.charAt(iter) == 'Q') {
				sb.append(q);
			} else if (original.charAt(iter) == 'R') {
				sb.append(r);
			} else if (original.charAt(iter) == 'S') {
				sb.append(s);
			} else if (original.charAt(iter) == 'T') {
				sb.append(t);
			} else if (original.charAt(iter) == 'U') {
				sb.append(u);
			} else if (original.charAt(iter) == 'V') {
				sb.append(v);
			} else if (original.charAt(iter) == 'W') {
				sb.append(w);
			} else if (original.charAt(iter) == 'X') {
				sb.append(x);
			} else if (original.charAt(iter) == 'Y') {
				sb.append(y);
			} else if (original.charAt(iter) == 'Z') {
				sb.append(z);
			} else {
				sb.append(original.charAt(iter));
			}
		}
		return sb.toString();
	}
	
	public Key concatenate(Key key) {
		Key newKey = new Key();
		if (a == nullChar) {
			if (key.getA() == nullChar) {
				newKey.setA(nullChar);
			} else {
				newKey.setA(key.getA());
			}
		} else {
			newKey.setA(a);
		}
		if (b == nullChar) {
			if (key.getB() == nullChar) {
				newKey.setB(nullChar);
			} else {
				newKey.setB(key.getB());
			}
		} else {
			newKey.setB(b);
		}
		if (c == nullChar) {
			if (key.getC() == nullChar) {
				newKey.setC(nullChar);
			} else {
				newKey.setC(key.getC());
			}
		} else {
			newKey.setC(c);
		}
		if (d == nullChar) {
			if (key.getD() == nullChar) {
				newKey.setD(nullChar);
			} else {
				newKey.setD(key.getD());
			}
		} else {
			newKey.setD(d);
		}
		if (e == nullChar) {
			if (key.getE() == nullChar) {
				newKey.setE(nullChar);
			} else {
				newKey.setE(key.getE());
			}
		} else {
			newKey.setE(e);
		}
		if (f == nullChar) {
			if (key.getF() == nullChar) {
				newKey.setF(nullChar);
			} else {
				newKey.setF(key.getF());
			}
		} else {
			newKey.setF(f);
		}
		if (g == nullChar) {
			if (key.getG() == nullChar) {
				newKey.setG(nullChar);
			} else {
				newKey.setG(key.getG());
			}
		} else {
			newKey.setG(g);
		}
		if (h == nullChar) {
			if (key.getH() == nullChar) {
				newKey.setH(nullChar);
			} else {
				newKey.setH(key.getH());
			}
		} else {
			newKey.setH(h);
		}
		if (i == nullChar) {
			if (key.getI() == nullChar) {
				newKey.setI(nullChar);
			} else {
				newKey.setI(key.getI());
			}
		} else {
			newKey.setI(i);
		}
		if (j == nullChar) {
			if (key.getJ() == nullChar) {
				newKey.setJ(nullChar);
			} else {
				newKey.setJ(key.getJ());
			}
		} else {
			newKey.setJ(j);
		}
		if (k == nullChar) {
			if (key.getK() == nullChar) {
				newKey.setK(nullChar);
			} else {
				newKey.setK(key.getK());
			}
		} else {
			newKey.setK(k);
		}
		if (l == nullChar) {
			if (key.getL() == nullChar) {
				newKey.setL(nullChar);
			} else {
				newKey.setL(key.getL());
			}
		} else {
			newKey.setL(l);
		}
		if (m == nullChar) {
			if (key.getM() == nullChar) {
				newKey.setM(nullChar);
			} else {
				newKey.setM(key.getM());
			}
		} else {
			newKey.setM(m);
		}
		if (n == nullChar) {
			if (key.getN() == nullChar) {
				newKey.setN(nullChar);
			} else {
				newKey.setN(key.getN());
			}
		} else {
			newKey.setN(n);
		}
		if (o == nullChar) {
			if (key.getO() == nullChar) {
				newKey.setO(nullChar);
			} else {
				newKey.setO(key.getO());
			}
		} else {
			newKey.setO(o);
		}
		if (p == nullChar) {
			if (key.getP() == nullChar) {
				newKey.setP(nullChar);
			} else {
				newKey.setP(key.getP());
			}
		} else {
			newKey.setP(p);
		}
		if (q == nullChar) {
			if (key.getQ() == nullChar) {
				newKey.setQ(nullChar);
			} else {
				newKey.setQ(key.getQ());
			}
		} else {
			newKey.setQ(q);
		}
		if (r == nullChar) {
			if (key.getR() == nullChar) {
				newKey.setR(nullChar);
			} else {
				newKey.setR(key.getR());
			}
		} else {
			newKey.setR(r);
		}
		if (s == nullChar) {
			if (key.getS() == nullChar) {
				newKey.setS(nullChar);
			} else {
				newKey.setS(key.getS());
			}
		} else {
			newKey.setS(s);
		}
		if (t == nullChar) {
			if (key.getT() == nullChar) {
				newKey.setT(nullChar);
			} else {
				newKey.setT(key.getT());
			}
		} else {
			newKey.setT(t);
		}
		if (u == nullChar) {
			if (key.getU() == nullChar) {
				newKey.setU(nullChar);
			} else {
				newKey.setU(key.getU());
			}
		} else {
			newKey.setU(u);
		}
		if (v == nullChar) {
			if (key.getV() == nullChar) {
				newKey.setV(nullChar);
			} else {
				newKey.setV(key.getV());
			}
		} else {
			newKey.setV(v);
		}
		if (w == nullChar) {
			if (key.getW() == nullChar) {
				newKey.setW(nullChar);
			} else {
				newKey.setW(key.getW());
			}
		} else {
			newKey.setW(w);
		}
		if (x == nullChar) {
			if (key.getX() == nullChar) {
				newKey.setX(nullChar);
			} else {
				newKey.setX(key.getX());
			}
		} else {
			newKey.setX(x);
		}
		if (y == nullChar) {
			if (key.getY() == nullChar) {
				newKey.setY(nullChar);
			} else {
				newKey.setY(key.getY());
			}
		} else {
			newKey.setY(y);
		}
		if (z == nullChar) {
			if (key.getZ() == nullChar) {
				newKey.setZ(nullChar);
			} else {
				newKey.setZ(key.getZ());
			}
		} else {
			newKey.setZ(z);
		}
		return newKey;
	}
	
	public boolean compatible(Key key) {
		boolean bool = true;
		if (a != key.getA() && a != nullChar && key.getA() != nullChar) {
			bool = false;
		} else if (b != key.getB() && b != nullChar && key.getB() != nullChar) {
			bool = false;
		} else if (c != key.getC() && c != nullChar && key.getC() != nullChar) {
			bool = false;
		} else if (d != key.getD() && d != nullChar && key.getD() != nullChar) {
			bool = false;
		} else if (e != key.getE() && e != nullChar && key.getE() != nullChar) {
			bool = false;
		} else if (f != key.getF() && f != nullChar && key.getF() != nullChar) {
			bool = false;
		} else if (g != key.getG() && g != nullChar && key.getG() != nullChar) {
			bool = false;
		} else if (h != key.getH() && h != nullChar && key.getH() != nullChar) {
			bool = false;
		} else if (i != key.getI() && i != nullChar && key.getI() != nullChar) {
			bool = false;
		} else if (j != key.getJ() && j != nullChar && key.getJ() != nullChar) {
			bool = false;
		} else if (k != key.getK() && k != nullChar && key.getK() != nullChar) {
			bool = false;
		} else if (l != key.getL() && l != nullChar && key.getL() != nullChar) {
			bool = false;
		} else if (m != key.getM() && m != nullChar && key.getM() != nullChar) {
			bool = false;
		} else if (n != key.getN() && n != nullChar && key.getN() != nullChar) {
			bool = false;
		} else if (o != key.getO() && o != nullChar && key.getO() != nullChar) {
			bool = false;
		} else if (p != key.getP() && p != nullChar && key.getP() != nullChar) {
			bool = false;
		} else if (q != key.getQ() && q != nullChar && key.getQ() != nullChar) {
			bool = false;
		} else if (r != key.getR() && r != nullChar && key.getR() != nullChar) {
			bool = false;
		} else if (s != key.getS() && s != nullChar && key.getS() != nullChar) {
			bool = false;
		} else if (t != key.getT() && t != nullChar && key.getT() != nullChar) {
			bool = false;
		} else if (u != key.getU() && u != nullChar && key.getU() != nullChar) {
			bool = false;
		} else if (v != key.getV() && v != nullChar && key.getV() != nullChar) {
			bool = false;
		} else if (w != key.getW() && w != nullChar && key.getW() != nullChar) {
			bool = false;
		} else if (x != key.getX() && x != nullChar && key.getX() != nullChar) {
			bool = false;
		} else if (y != key.getY() && y != nullChar && key.getY() != nullChar) {
			bool = false;
		} else if (z != key.getZ() && z != nullChar && key.getZ() != nullChar) {
			bool = false;
		}
		return bool;
	}

	public char[] toArray() {
		char[] key = new char[26];
		if (a != nullChar) {
			key[0] = a;
		} else {
			key[0] = '#';
		}
		if (b != nullChar) {
			key[1] = b;
		} else {
			key[1] = '#';
		}
		if (c != nullChar) {
			key[2] = c;
		} else {
			key[2] = '#';
		}
		if (d != nullChar) {
			key[3] = d;
		} else {
			key[3] = '#';
		}
		if (e != nullChar) {
			key[4] = e;
		} else {
			key[4] = '#';
		}
		if (f != nullChar) {
			key[5] = f;
		} else {
			key[5] = '#';
		}
		if (g != nullChar) {
			key[6] = g;
		} else {
			key[6] = '#';
		}
		if (h != nullChar) {
			key[7] = h;
		} else {
			key[7] = '#';
		}
		if (i != nullChar) {
			key[8] = i;
		} else {
			key[8] = '#';
		}
		if (j != nullChar) {
			key[9] = j;
		} else {
			key[9] = '#';
		}
		if (k != nullChar) {
			key[10] = k;
		} else {
			key[10] = '#';
		}
		if (l != nullChar) {
			key[11] = l;
		} else {
			key[11] = '#';
		}
		if (m != nullChar) {
			key[12] = m;
		} else {
			key[12] = '#';
		}
		if (n != nullChar) {
			key[13] = n;
		} else {
			key[13] = '#';
		}
		if (o != nullChar) {
			key[14] = o;
		} else {
			key[14] = '#';
		}
		if (p != nullChar) {
			key[15] = p;
		} else {
			key[15] = '#';
		}
		if (q != nullChar) {
			key[16] = q;
		} else {
			key[16] = '#';
		}
		if (r != nullChar) {
			key[17] = r;
		} else {
			key[17] = '#';
		}
		if (s != nullChar) {
			key[18] = s;
		} else {
			key[18] = '#';
		}
		if (t != nullChar) {
			key[19] = t;
		} else {
			key[19] = '#';
		}
		if (u != nullChar) {
			key[20] = u;
		} else {
			key[20] = '#';
		}
		if (v != nullChar) {
			key[21] = v;
		} else {
			key[21] = '#';
		}
		if (w != nullChar) {
			key[22] = w;
		} else {
			key[22] = '#';
		}
		if (x != nullChar) {
			key[23] = x;
		} else {
			key[23] = '#';
		}
		if (y != nullChar) {
			key[24] = y;
		} else {
			key[24] = '#';
		}
		if (z != nullChar) {
			key[25] = z;
		} else {
			key[25] = '#';
		}
		return key;
	}

	public char getA() {
		return a;
	}

	public char getB() {
		return b;
	}

	public char getC() {
		return c;
	}

	public char getD() {
		return d;
	}

	public char getE() {
		return e;
	}

	public char getF() {
		return f;
	}

	public char getG() {
		return g;
	}

	public char getH() {
		return h;
	}

	public char getI() {
		return i;
	}

	public char getJ() {
		return j;
	}

	public char getK() {
		return k;
	}

	public char getL() {
		return l;
	}

	public char getM() {
		return m;
	}

	public char getN() {
		return n;
	}

	public char getO() {
		return o;
	}

	public char getP() {
		return p;
	}

	public char getQ() {
		return q;
	}

	public char getR() {
		return r;
	}

	public char getS() {
		return s;
	}

	public char getT() {
		return t;
	}

	public char getU() {
		return u;
	}

	public char getV() {
		return v;
	}

	public char getW() {
		return w;
	}

	public char getX() {
		return x;
	}

	public char getY() {
		return y;
	}

	public char getZ() {
		return z;
	}

	public void setA(char c) {
		a = c;
	}

	public void setB(char c) {
		b = c;
	}

	public void setC(char C) {
		c = C;
	}

	public void setD(char c) {
		d = c;
	}

	public void setE(char c) {
		e = c;
	}

	public void setF(char c) {
		f = c;
	}

	public void setG(char c) {
		g = c;
	}

	public void setH(char c) {
		h = c;
	}

	public void setI(char c) {
		i = c;
	}

	public void setJ(char c) {
		j = c;
	}

	public void setK(char c) {
		k = c;
	}

	public void setL(char c) {
		l = c;
	}

	public void setM(char c) {
		m = c;
	}

	public void setN(char c) {
		n = c;
	}

	public void setO(char c) {
		o = c;
	}

	public void setP(char c) {
		p = c;
	}

	public void setQ(char c) {
		q = c;
	}

	public void setR(char c) {
		r = c;
	}

	public void setS(char c) {
		s = c;
	}

	public void setT(char c) {
		t = c;
	}

	public void setU(char c) {
		u = c;
	}

	public void setV(char c) {
		v = c;
	}

	public void setW(char c) {
		w = c;
	}

	public void setX(char c) {
		x = c;
	}

	public void setY(char c) {
		y = c;
	}

	public void setZ(char c) {
		z = c;
	}
}
